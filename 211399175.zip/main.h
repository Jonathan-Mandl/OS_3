#ifndef MAIN_H
#define MAIN_H

// struct to store the arguments of producer function in order to call function with thread.
typedef struct
{
    int id;
    int num_products;
    int queue_size;
} producer_args;

// function to get message type: sports, weather or news from message.
char *ExtractMessageType(const char *message);

// function for producer. called by producer thread.
void *producer(void *args);

void *dispatcher(void *arg);

void *coEditor(void *type);

void *screen_manager();

int main(int argc, char *argv[]);

#endif /* MAIN_H */
